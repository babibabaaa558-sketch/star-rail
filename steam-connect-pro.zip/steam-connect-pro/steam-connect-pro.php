<?php
/*
Plugin Name: Steam Connect Pro
Description: Connect Steam accounts and display connected users publicly.
Version: 1.2.0
Author: You
Text Domain: steam-connect-pro
Domain Path: /languages
*/

if (! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'SCP_VERSION', '1.2.0' );
define( 'SCP_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'SCP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

add_action( 'after_setup_theme', function() {
    if ( ! is_admin() && ! current_user_can( 'manage_options' ) ) {
        show_admin_bar( false );
    }
} );

require_once SCP_PLUGIN_PATH . 'includes/api.php';
require_once SCP_PLUGIN_PATH . 'includes/verification-badge.php';
require_once SCP_PLUGIN_PATH . 'includes/auth.php';
require_once SCP_PLUGIN_PATH . 'includes/users-list.php';
require_once SCP_PLUGIN_PATH . 'includes/ajax.php';
require_once SCP_PLUGIN_PATH . 'includes/admin.php';
require_once SCP_PLUGIN_PATH . 'includes/public-profile.php';
require_once SCP_PLUGIN_PATH . 'includes/chat.php';
require_once SCP_PLUGIN_PATH . 'includes/friends.php';
require_once SCP_PLUGIN_PATH . 'includes/friends-list.php';

register_activation_hook( __FILE__, function () {
    scp_chat_install_tables();
    scp_friends_install_table();
    scp_add_rewrite_rule();
    flush_rewrite_rules();
} );

register_deactivation_hook( __FILE__, function () {
    flush_rewrite_rules();
} );

function scp_add_rewrite_rule() {
    add_rewrite_rule(
        '^steam-user/([0-9]+)/?$',
        'index.php?scp_steam_user=$matches[1]',
        'top'
    );

    add_rewrite_rule(
        '^steam-user/site/([0-9]+)/?$',
        'index.php?scp_site_user=$matches[1]',
        'top'
    );
}
add_action('init', 'scp_add_rewrite_rule');

function scp_add_query_vars($vars) {
    $vars[] = 'scp_steam_user';
    $vars[] = 'scp_site_user';
    return $vars;
}
add_filter('query_vars', 'scp_add_query_vars');

add_action( 'wp_enqueue_scripts', function () {
    wp_enqueue_style( 'scp-style', SCP_PLUGIN_URL . 'assets/css/style.css', [], SCP_VERSION );
    wp_enqueue_style( 'scp-chat-style', SCP_PLUGIN_URL . 'assets/css/chat.css', [ 'scp-style' ], SCP_VERSION );
    wp_enqueue_style( 'scp-friends-list-style', SCP_PLUGIN_URL . 'assets/css/friends-list.css', [ 'scp-style' ], SCP_VERSION );
    wp_register_script( 'scp-online', SCP_PLUGIN_URL . 'assets/js/online-status.js', [ 'jquery' ], SCP_VERSION, true );
    wp_register_script( 'scp-chat', SCP_PLUGIN_URL . 'assets/js/chat.js', [], SCP_VERSION, true );
    wp_register_script( 'scp-friends', SCP_PLUGIN_URL . 'assets/js/friends.js', [], SCP_VERSION, true );
    wp_register_script( 'scp-friends-list', SCP_PLUGIN_URL . 'assets/js/friends-list.js', [], SCP_VERSION, true );

    $scp_ajax_data = [
        'ajax_url' => admin_url( 'admin-ajax.php' ),
        'nonce'    => wp_create_nonce( 'scp-ajax' ),
        'current_user_id' => get_current_user_id(),
        'current_user' => is_user_logged_in() ? [
            'id' => get_current_user_id(),
            'name' => wp_get_current_user()->display_name,
            'avatar' => scp_get_user_avatar_url( get_current_user_id(), 64 ),
        ] : null,
        'labels' => [
            'chat_with' => __( 'Chat with', 'steam-connect-pro' ),
            'no_rooms' => __( 'No chat rooms yet.', 'steam-connect-pro' ),
        ],
    ];

    wp_localize_script( 'scp-online', 'scpAjax', $scp_ajax_data );
    wp_localize_script( 'scp-chat', 'scpAjax', $scp_ajax_data );
    wp_localize_script( 'scp-friends', 'scpAjax', $scp_ajax_data );
    wp_localize_script( 'scp-friends-list', 'scpAjax', $scp_ajax_data );

    wp_enqueue_script( 'scp-online' );
    if ( is_user_logged_in() ) {
        wp_enqueue_script( 'scp-chat' );
        wp_enqueue_script( 'scp-friends' );
        wp_enqueue_script( 'scp-friends-list' );
    }
} );
