(function () {
    const wrapper = document.querySelector('.scp-public-tabs');
    if (!wrapper || typeof scpPublicTabs === 'undefined') {
        return;
    }

    const content = wrapper.querySelector('.scp-public-tabs-content');
    const buttons = wrapper.querySelectorAll('.scp-public-tab-btn');
    const steamId = wrapper.getAttribute('data-steam-id') || '';
    const querySiteUserId = new URLSearchParams(window.location.search).get('scp_site_user') || '';
    const siteUserId = wrapper.getAttribute('data-site-user-id') || querySiteUserId;

    const setActive = (tab) => {
        buttons.forEach((btn) => {
            btn.classList.toggle('is-active', btn.dataset.tab === tab);
        });
    };

    const renderLoading = () => {
        content.innerHTML = '<div class="scp-empty-state">در حال بارگذاری...</div>';
    };

    const loadTab = async (tab) => {
        renderLoading();

        const body = new URLSearchParams({
            action: 'scp_load_public_profile_tab',
            nonce: scpPublicTabs.nonce,
            steam_id: steamId,
            site_user_id: siteUserId,
            tab,
        });

        const response = await fetch(scpPublicTabs.ajaxUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
            body: body.toString(),
        });

        if (!response.ok) {
            throw new Error('request_failed');
        }

        const data = await response.json();
        if (!data || !data.success) {
            throw new Error('invalid_response');
        }

        content.innerHTML = data.data.html;

        if (tab === 'arknight-endfield-accounts' && typeof window.ArknightEndfieldCardsInit === 'function') {
            window.ArknightEndfieldCardsInit(content);
        }
    };

    buttons.forEach((button) => {
        button.addEventListener('click', async function () {
            const tab = this.dataset.tab || 'info';
            if (this.classList.contains('is-active')) {
                return;
            }

            setActive(tab);

            try {
                await loadTab(tab);
            } catch (e) {
                content.innerHTML = '<div class="scp-empty-state">بارگذاری ناموفق بود. دوباره تلاش کنید.</div>';
            }
        });
    });
})();
