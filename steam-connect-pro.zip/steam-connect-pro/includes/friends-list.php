<?php
if (!defined('ABSPATH')) {
    exit;
}

function scp_friends_list_profile_url($friend) {
    $url = isset($friend['public_profile_url']) ? (string) $friend['public_profile_url'] : '';
    if (!empty($url)) {
        return $url;
    }

    $friend_id = isset($friend['id']) ? (int) $friend['id'] : 0;
    return $friend_id > 0 ? add_query_arg('scp_site_user', $friend_id, home_url('/')) : '#';
}

function scp_friends_list_shortcode() {
    if (!is_user_logged_in()) {
        return '<div class="scp-friends-list-wrap"><h3 class="scp-friends-page-title">Your friends</h3><div class="scp-friends-list-empty">برای مشاهده دوستان، وارد شوید.</div></div>';
    }

    $friends = scp_friends_get_user_friends(get_current_user_id(), 200);

    ob_start();
    ?>
    <div class="scp-friends-list-wrap" id="scp-friends-list-root">
        <h3 class="scp-friends-page-title">Your friends</h3>
        <div class="scp-friends-grid" id="scp-friends-grid">
            <?php if (!empty($friends)) : ?>
                <?php foreach ($friends as $friend) : ?>
                    <?php $profile_url = scp_friends_list_profile_url($friend); ?>
                    <div class="scp-friends-item" data-friend-id="<?php echo esc_attr((string) $friend['id']); ?>">
                        <div class="scp-friends-item-main">
                            <a href="<?php echo esc_url($profile_url); ?>" class="scp-friend-user-link">
                                <span class="scp-avatar-presence-wrap" data-scp-site-user-id="<?php echo esc_attr((string) $friend['id']); ?>">
                                    <img src="<?php echo esc_url($friend['user']['avatar']); ?>" alt="<?php echo esc_attr($friend['user']['name']); ?>">
                                    <span class="scp-site-presence-dot offline" data-tooltip="آفلاین در سایت"></span>
                                </span>
                            </a>
                            <div class="scp-friends-item-meta">
                                <a href="<?php echo esc_url($profile_url); ?>" class="scp-friend-user-link"><strong><?php echo esc_html($friend['user']['name']); ?><?php echo !empty($friend['user']['is_verified']) ? scp_get_verified_badge_html((int) $friend['id'], ['class' => 'scp-verified-badge-inline']) : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></strong></a>
                                <span><?php echo esc_html(sprintf('دوست از %s پیش', $friend['since_human'])); ?></span>
                            </div>
                        </div>

                        <div class="scp-friends-item-actions">
                            <div class="scp-friend-split" data-target-user="<?php echo esc_attr((string) $friend['id']); ?>">
                                <button type="button" class="scp-friend-btn is-friends" data-friend-state="friends" disabled>Friends</button>
                                <button type="button" class="scp-friend-btn is-remove" data-friend-action="remove" data-target-user="<?php echo esc_attr((string) $friend['id']); ?>">Remove Friend</button>
                            </div>
                            <button type="button" class="scp-chat-launch scp-chat-launch-profile" data-target-user="<?php echo esc_attr((string) $friend['id']); ?>" data-target-name="<?php echo esc_attr($friend['user']['name']); ?>">💬 Chat</button>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else : ?>
                <div class="scp-friends-list-empty">هنوز دوستی ثبت نشده است.</div>
            <?php endif; ?>
        </div>
    </div>
    <?php

    return ob_get_clean();
}
add_shortcode('scp_friends_list', 'scp_friends_list_shortcode');

add_action('wp_ajax_scp_get_friends_list', function () {
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'unauthorized'], 401);
    }

    if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'scp-ajax')) {
        wp_send_json_error(['message' => 'invalid_nonce'], 400);
    }

    $friends = scp_friends_get_user_friends(get_current_user_id(), 200);
    wp_send_json_success(['items' => $friends]);
});
