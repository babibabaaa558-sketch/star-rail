<?php
if (!defined('ABSPATH')) {
    exit;
}

function scp_public_profile_get_level_class($steam_level) {
    $steam_level = (int) $steam_level;

    if ($steam_level >= 101) {
        return 'scp-level-platinum';
    }

    if ($steam_level >= 61) {
        return 'scp-level-gold';
    }

    if ($steam_level >= 31) {
        return 'scp-level-silver';
    }

    if ($steam_level >= 11) {
        return 'scp-level-bronze';
    }

    return 'scp-level-basic';
}

function scp_public_profile_render_games_section($title, $games, $empty_text, $limit = 0) {
    $games = is_array($games) ? $games : [];
    if ($limit > 0) {
        $games = array_slice($games, 0, $limit);
    }

    ob_start();
    ?>
    <div class="scp-section-header">
        <h3 class="scp-section-title"><?php echo esc_html($title); ?></h3>
    </div>

    <div class="scp-games-grid">
        <?php if (!empty($games)) : ?>
            <?php foreach ($games as $game) :
                $appid = isset($game['appid']) ? (int) $game['appid'] : 0;
                $name = isset($game['name']) ? $game['name'] : '';
                $playtime = isset($game['playtime_forever']) ? (float) $game['playtime_forever'] : 0;
                ?>
                <div class="scp-game-card">
                    <img src="https://cdn.cloudflare.steamstatic.com/steam/apps/<?php echo esc_attr($appid); ?>/header.jpg" alt="<?php echo esc_attr($name); ?>">
                    <div class="scp-game-info">
                        <strong><?php echo esc_html($name); ?></strong>
                        <div class="scp-playtime-badge"><?php echo esc_html(round($playtime / 60, 1)); ?> ساعت بازی</div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else : ?>
            <div class="scp-empty-state"><?php echo esc_html($empty_text); ?></div>
        <?php endif; ?>
    </div>
    <?php

    return ob_get_clean();
}


function scp_public_profile_resolve_site_user_id($site_user_id = 0) {
    $site_user_id = absint($site_user_id);

    if ($site_user_id > 0) {
        return $site_user_id;
    }

    $query_var_user = absint(get_query_var('scp_site_user'));
    if ($query_var_user > 0) {
        return $query_var_user;
    }

    if (isset($_GET['scp_site_user'])) {
        $get_user = absint(wp_unslash($_GET['scp_site_user']));
        if ($get_user > 0) {
            return $get_user;
        }
    }

    return 0;
}

function scp_public_profile_allowed_tabs() {
    return [
        'info',
        'items',
        'accounts',
        'arknight-endfield-accounts',
    ];
}

function scp_public_profile_tab_content($steam_id, $tab, $site_user_id = 0) {
    $steam_id = sanitize_text_field((string) $steam_id);
    $tab = sanitize_key((string) $tab);
    $site_user_id = scp_public_profile_resolve_site_user_id($site_user_id);

    if (!in_array($tab, scp_public_profile_allowed_tabs(), true)) {
        $tab = 'info';
    }

    if ($tab === 'items') {
        return do_shortcode('[for-sale-user-item]');
    }

    if ($tab === 'accounts') {
        return do_shortcode('[scx_user_store_listings]');
    }

    if ($tab === 'arknight-endfield-accounts') {
        if ($site_user_id <= 0) {
            return '<div class="scp-empty-state">شناسه کاربری معتبر برای نمایش آکانت‌ها یافت نشد.</div>';
        }

        if (!shortcode_exists('arknight_profile_endfield_accounts')) {
            return '<div class="scp-empty-state">افزونه نمایش آکانت‌های Arknight Endfield در دسترس نیست.</div>';
        }

        return do_shortcode('[arknight_profile_endfield_accounts author_id="' . $site_user_id . '"]');
    }


    if ($tab === 'info' && !$steam_id) {
        return '<div class="scp-empty-state">اطلاعات استیم برای این کاربر در دسترس نیست.</div>';
    }

    $recent_games = scp_get_recent_games($steam_id);
    $owned_games = scp_get_owned_games($steam_id);

    if (!empty($recent_games)) {
        usort($recent_games, function ($a, $b) {
            return ($b['playtime_forever'] ?? 0) <=> ($a['playtime_forever'] ?? 0);
        });
    }

    if (!empty($owned_games)) {
        usort($owned_games, function ($a, $b) {
            return ($b['playtime_forever'] ?? 0) <=> ($a['playtime_forever'] ?? 0);
        });
    }

    return scp_public_profile_render_games_section('بازی اخیراً پلی شده', $recent_games, 'هیچ بازی اخیری پیدا نشد')
        . scp_public_profile_render_games_section('بازی‌هایی که این کاربر تجربه کرده', $owned_games, 'هیچ بازی‌ای یافت نشد', 24);
}

function scp_public_profile_render_tabs($steam_id, $site_user_id = 0) {
    $steam_id = sanitize_text_field((string) $steam_id);
    $site_user_id = scp_public_profile_resolve_site_user_id($site_user_id);
    ob_start();
    ?>
    <section class="scp-public-tabs" data-steam-id="<?php echo esc_attr($steam_id); ?>" data-site-user-id="<?php echo esc_attr($site_user_id); ?>">
        <div class="scp-public-tabs-nav" role="tablist" aria-label="Public profile tabs">
            <button type="button" class="scp-public-tab-btn is-active" data-tab="info">اطلاعات کاربر</button>
            <button type="button" class="scp-public-tab-btn" data-tab="items">آیتم های برای فروش</button>
            <button type="button" class="scp-public-tab-btn" data-tab="accounts">آکانت برای فروش این کاربر</button>
            <button type="button" class="scp-public-tab-btn" data-tab="arknight-endfield-accounts">آکانت های Arknight Endfield</button>
        </div>

        <div class="scp-public-tabs-content" id="scp-public-tabs-content">
            <?php echo scp_public_profile_tab_content($steam_id, 'info', $site_user_id); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
        </div>
    </section>
    <?php

    return ob_get_clean();
}

add_action('wp_ajax_scp_load_public_profile_tab', 'scp_ajax_load_public_profile_tab');
add_action('wp_ajax_nopriv_scp_load_public_profile_tab', 'scp_ajax_load_public_profile_tab');
function scp_ajax_load_public_profile_tab() {
    check_ajax_referer('scp-public-profile-tabs', 'nonce');

    $steam_id = isset($_POST['steam_id']) ? sanitize_text_field(wp_unslash($_POST['steam_id'])) : '';
    $tab = isset($_POST['tab']) ? sanitize_key(wp_unslash($_POST['tab'])) : 'info';
    if (!in_array($tab, scp_public_profile_allowed_tabs(), true)) {
        $tab = 'info';
    }

    $site_user_id = isset($_POST['site_user_id']) ? absint(wp_unslash($_POST['site_user_id'])) : 0;
    $site_user_id = scp_public_profile_resolve_site_user_id($site_user_id);

    wp_send_json_success([
        'html' => scp_public_profile_tab_content($steam_id, $tab, $site_user_id),
    ]);
}

add_action('wp_enqueue_scripts', function () {
    $has_profile_query = get_query_var('scp_steam_user') || get_query_var('scp_site_user');

    if (!$has_profile_query && isset($_GET['scp_site_user'])) {
        $has_profile_query = absint(wp_unslash($_GET['scp_site_user'])) > 0;
    }

    if (!$has_profile_query && isset($_GET['scp_steam_user'])) {
        $has_profile_query = sanitize_text_field(wp_unslash($_GET['scp_steam_user'])) !== '';
    }

    if (!$has_profile_query) {
        return;
    }


    wp_enqueue_style(
        'scp-public-profile-tabs',
        SCP_PLUGIN_URL . 'assets/css/public-profile-tabs.css',
        ['scp-style'],
        SCP_VERSION
    );

        $scp_endfield_inline_css = <<<'CSS'
.scp-public-tabs-content .arkn-product-card__tabs{display:flex!important;gap:7px!important;flex-wrap:wrap!important;align-items:center!important;}
.scp-public-tabs-content .arkn-product-card__tab{appearance:none!important;border:1px solid rgba(125,146,220,.55)!important;background:rgba(13,20,45,.95)!important;color:#d8e8ff!important;box-shadow:inset 0 0 0 1px rgba(79,209,255,.16)!important;border-radius:9px!important;padding:6px 10px!important;font-size:11px!important;font-weight:700!important;line-height:1.4!important;cursor:pointer!important;transition:all .22s ease!important;}
.scp-public-tabs-content .arkn-product-card__tab:hover{border-color:rgba(79,209,255,.9)!important;box-shadow:0 8px 18px rgba(79,209,255,.2)!important;transform:translateY(-1px)!important;}
.scp-public-tabs-content .arkn-product-card__tab.is-active{background:linear-gradient(120deg, rgba(79,209,255,.24), rgba(139,92,246,.34))!important;border-color:rgba(79,209,255,.88)!important;color:#fff!important;box-shadow:0 0 18px rgba(79,209,255,.3)!important;}
.scp-public-tabs-content .arkn-product-card__desktop-only{display:flex!important;justify-content:flex-end!important;gap:6px!important;flex-wrap:wrap!important;}
.scp-public-tabs-content .arkn-product-card__hover-trigger{appearance:none!important;display:inline-flex!important;align-items:center!important;gap:6px!important;border:1px solid rgba(125,146,220,.5)!important;background:rgba(12,18,39,.92)!important;color:#d8e8ff!important;border-radius:9px!important;padding:6px 10px!important;font-size:11px!important;font-weight:700!important;line-height:1.3!important;cursor:pointer!important;transition:all .22s ease!important;}
.scp-public-tabs-content .arkn-product-card__hover-trigger::after{content:''!important;display:inline-block!important;width:6px!important;height:6px!important;border-radius:50%!important;background:#4fd1ff!important;box-shadow:0 0 0 0 rgba(78,230,255,.55)!important;animation:scpArknHoverPulse 1.7s ease-in-out infinite!important;flex-shrink:0!important;}
.scp-public-tabs-content .arkn-product-card__hover-trigger:hover{border-color:rgba(79,209,255,.9)!important;transform:translateY(-1px)!important;}
.scp-public-tabs-content .arkn-product-card__hover.is-open .arkn-product-card__hover-trigger{border-color:rgba(79,209,255,.9)!important;background:rgba(24,34,74,.95)!important;box-shadow:0 8px 16px rgba(79,209,255,.2)!important;transform:translateY(-1px)!important;}
.scp-public-tabs-content .arkn-product-card__hover.is-open .arkn-product-card__hover-content{display:block!important;opacity:1!important;visibility:visible!important;transform:translateY(0)!important;}
.scp-public-tabs-content .arkn-product-card__hover-content{display:none!important;}
@keyframes scpArknHoverPulse{0%{box-shadow:0 0 0 0 rgba(78,230,255,.55);}70%{box-shadow:0 0 0 7px rgba(78,230,255,0);}100%{box-shadow:0 0 0 0 rgba(78,230,255,0);}}
CSS;

wp_add_inline_style('scp-public-profile-tabs', $scp_endfield_inline_css);

    wp_enqueue_script(
        'scp-public-profile-tabs',
        SCP_PLUGIN_URL . 'assets/js/public-profile-tabs.js',
        [],
        SCP_VERSION,
        true
    );

    wp_localize_script('scp-public-profile-tabs', 'scpPublicTabs', [
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('scp-public-profile-tabs'),
    ]);


    if (defined('ARKN_EDD_FORM_URL') && defined('ARKN_EDD_FORM_VERSION')) {
        wp_enqueue_style(
            'arkn-account-cards-style',
            ARKN_EDD_FORM_URL . 'assets/css/product-cards.css',
            [],
            ARKN_EDD_FORM_VERSION
        );

        wp_enqueue_script(
            'arkn-account-cards-script',
            ARKN_EDD_FORM_URL . 'assets/js/product-cards.js',
            [],
            ARKN_EDD_FORM_VERSION,
            true
        );
    }

});
