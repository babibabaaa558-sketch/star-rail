<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Build Steam OpenID URL.
 */
function scp_get_steam_openid_url($current_url = '') {
    $current_url = $current_url ? esc_url_raw($current_url) : home_url('/');

    $openid_params = [
        'openid.ns'         => 'http://specs.openid.net/auth/2.0',
        'openid.mode'       => 'checkid_setup',
        'openid.return_to'  => home_url('/steam-auth-callback') . '?redirect=' . urlencode($current_url),
        'openid.realm'      => home_url(),
        'openid.identity'   => 'http://specs.openid.net/auth/2.0/identifier_select',
        'openid.claimed_id' => 'http://specs.openid.net/auth/2.0/identifier_select',
    ];

    return 'https://steamcommunity.com/openid/login?' . http_build_query($openid_params);
}

/**
 * Find a user by steam_id meta.
 */
function scp_find_user_by_steam_id($steam_id) {
    $users = get_users([
        'meta_key'   => 'steam_id',
        'meta_value' => sanitize_text_field($steam_id),
        'number'     => 1,
        'fields'     => ['ID'],
    ]);

    if (!empty($users) && isset($users[0]->ID)) {
        return (int) $users[0]->ID;
    }

    return 0;
}
/**
 * Check if steam already registered
 */
function scp_is_steam_registered($steam_id) {
    return scp_find_user_by_steam_id($steam_id) ? true : false;
}

/**
 * Create a new WP user for a Steam account.
 */
function scp_create_user_from_steam($steam_id) {
    $steam_user = scp_get_steam_user_info($steam_id);
    $base_login = 'steam_' . sanitize_user($steam_id);
    $user_login = $base_login;
    $suffix = 1;

    while (username_exists($user_login)) {
        $user_login = $base_login . '_' . $suffix;
        $suffix++;
    }

    // WordPress expects a valid email format for user creation on most setups.
    // We use a placeholder email on a reserved domain so registration always works.
    $email = scp_generate_unique_placeholder_email($user_login);

    $display_name = !empty($steam_user['name']) ? sanitize_text_field($steam_user['name']) : 'Steam User ' . $steam_id;

    $user_id = wp_insert_user([
        'user_login'   => $user_login,
        'user_pass'    => wp_generate_password(24, true, true),
        'user_email'   => $email,
        'display_name' => $display_name,
        'nickname'     => $display_name,
        'role'         => get_option('default_role', 'subscriber'),
    ]);

    if (is_wp_error($user_id)) {
        return 0;
    }

    $steam_id = sanitize_text_field($steam_id);

delete_user_meta($user_id, 'steam_id');
update_user_meta($user_id, 'steam_id', $steam_id);
scp_sync_steam_profile_meta($user_id, $steam_id, $steam_user);

// Race condition check
$already = scp_find_user_by_steam_id($steam_id);

if ($already && $already != $user_id) {
    wp_delete_user($user_id);
    return $already;
}

return (int) $user_id;

}

/**
 * Save Steam profile fields to user meta for easy reuse across the site.
 */
function scp_sync_steam_profile_meta($user_id, $steam_id, $steam_user = []) {
    $user_id = (int) $user_id;
    $steam_id = sanitize_text_field($steam_id);

    if ($user_id <= 0 || !$steam_id) {
        return;
    }

    if (empty($steam_user) || !is_array($steam_user)) {
        $steam_user = scp_get_steam_user_info($steam_id);
    }

    $steam_name = !empty($steam_user['name']) ? sanitize_text_field($steam_user['name']) : '';
    $steam_avatar = !empty($steam_user['avatar']) ? esc_url_raw($steam_user['avatar']) : '';

    update_user_meta($user_id, 'steam_name', $steam_name);
    update_user_meta($user_id, 'steam_avatar', $steam_avatar);
}

/**
 * Get user avatar with WordPress priority, then Steam fallback.
 */
function scp_get_user_avatar_url($user_id, $size = 96) {
    $user_id = (int) $user_id;
    if ($user_id <= 0) {
        return '';
    }

    $avatar_data = get_avatar_data($user_id, ['size' => (int) $size]);
    $wp_avatar_url = !empty($avatar_data['url']) ? esc_url_raw($avatar_data['url']) : '';

    if ($wp_avatar_url !== '' && scp_user_has_custom_wordpress_avatar($user_id, $wp_avatar_url)) {
        return $wp_avatar_url;
    }

    $steam_avatar = get_user_meta($user_id, 'steam_avatar', true);
    if (!empty($steam_avatar)) {
        return esc_url_raw($steam_avatar);
    }

    $steam_id = sanitize_text_field((string) get_user_meta($user_id, 'steam_id', true));
    if ($steam_id && function_exists('scp_get_steam_user_info')) {
        $steam_user = scp_get_steam_user_info($steam_id, true);
        if (!empty($steam_user['avatar'])) {
            $steam_avatar = esc_url_raw($steam_user['avatar']);
            update_user_meta($user_id, 'steam_avatar', $steam_avatar);
            return $steam_avatar;
        }
    }

    return get_avatar_url($user_id, ['size' => (int) $size]);
}

/**
 * Detect whether user has a custom avatar set in WordPress/Gravatar.
 *
 * - Local avatars (non-gravatar URLs) are treated as custom.
 * - For Gravatar URLs, we probe with `d=404` and cache result.
 */
function scp_user_has_custom_wordpress_avatar($user_id, $avatar_url = '') {
    $user_id = (int) $user_id;
    if ($user_id <= 0 || $avatar_url === '') {
        return false;
    }

    $is_gravatar = (strpos($avatar_url, 'gravatar.com/avatar/') !== false || strpos($avatar_url, 'secure.gravatar.com/avatar/') !== false);
    if (!$is_gravatar) {
        return true;
    }

    $cache_key = 'scp_has_custom_gravatar_' . $user_id;
    $cached = get_transient($cache_key);
    if ($cached !== false) {
        return $cached === '1';
    }

    $user = get_userdata($user_id);
    if (!$user || empty($user->user_email)) {
        set_transient($cache_key, '0', HOUR_IN_SECONDS * 12);
        return false;
    }

    $hash = md5(strtolower(trim($user->user_email)));
    $probe_url = add_query_arg(
        [
            'd' => '404',
            's' => 96,
            'r' => 'g',
        ],
        'https://www.gravatar.com/avatar/' . $hash
    );

    $response = wp_remote_head($probe_url, ['timeout' => 4]);
    if (is_wp_error($response)) {
        set_transient($cache_key, '0', HOUR_IN_SECONDS);
        return false;
    }

    $code = (int) wp_remote_retrieve_response_code($response);
    $has_custom = $code >= 200 && $code < 300;

    set_transient($cache_key, $has_custom ? '1' : '0', HOUR_IN_SECONDS * 12);

    return $has_custom;
}

/**
 * Generate a unique placeholder email for Steam-created accounts.
 * Uses the reserved .invalid TLD to avoid real email collisions.
 */
function scp_generate_unique_placeholder_email($user_login) {
    $base = sanitize_user($user_login, true);
    if (!$base) {
        $base = 'steam_user';
    }

    $email = $base . '@steam.invalid';

    while (email_exists($email)) {
        $email = $base . '_' . wp_generate_password(6, false, false) . '@steam.invalid';
    }

    return $email;
}

/**
 * Find existing user by steam id, or create user if not found.
 */
function scp_get_or_create_user_by_steam($steam_id) {
    $user_id = scp_find_user_by_steam_id($steam_id);

    if ($user_id) {
        return $user_id;
    }

    return scp_create_user_from_steam($steam_id);
}

/**
 * Shortcode: [steam_connect_button]
 * Steam connect / profile / disconnect
 */
function scp_steam_connect_shortcode() {
    $is_logged_in = is_user_logged_in();
    $user_id = get_current_user_id();
    $steam_id = $user_id ? get_user_meta($user_id, 'steam_id', true) : '';

    $request_uri = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '/';
    $current_url = esc_url(home_url(add_query_arg([], $request_uri)));
    $openid_url = scp_get_steam_openid_url($current_url);

    ob_start();
?>
<div class="scp-box">
        <?php if ($is_logged_in && $steam_id) :
            $steam_user = scp_get_steam_user_info($steam_id);
            if ($steam_user) :
                scp_sync_steam_profile_meta($user_id, $steam_id, $steam_user);
                $steam_level = intval($steam_user['level']);
                $level_class = 'scp-level-basic';

                if ($steam_level >= 11 && $steam_level <= 30) {
                    $level_class = 'scp-level-bronze';
                } elseif ($steam_level >= 31 && $steam_level <= 60) {
                    $level_class = 'scp-level-silver';
                } elseif ($steam_level >= 61 && $steam_level <= 100) {
                    $level_class = 'scp-level-gold';
                } elseif ($steam_level >= 101) {
                    $level_class = 'scp-level-platinum';
                }
                ?>

                <!-- TOP BAR -->
                <div class="scp-top-bar">
                    <div class="scp-success">
                        <span class="scp-check">✔</span>
                        <span>Steam Connected</span>
                    </div>

                    <form method="POST" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                        <input type="hidden" name="action" value="scp_disconnect_steam">
                        <?php wp_nonce_field('scp_disconnect_action', 'scp_disconnect_nonce'); ?>
                        <button type="submit" class="scp-btn scp-btn-danger scp-btn-sm">
                            Disconnect
                        </button>
                    </form>
                </div>

                <!-- PROFILE -->
                <div class="scp-profile">
                    <img src="<?php echo esc_url($steam_user['avatar']); ?>" class="scp-avatar" alt="">
                    <div class="scp-info">
                        <strong><?php echo esc_html($steam_user['name']); ?></strong>
                        <div class="scp-meta-row">
                            <span class="scp-level-badge <?php echo esc_attr($level_class); ?>" data-tooltip="<?php esc_attr_e('Steam Level', 'steam-connect-pro'); ?>">
                                <?php printf(esc_html__('Lv. %d', 'steam-connect-pro'), $steam_level); ?>
                            </span>
                        </div>
                        <a href="<?php echo esc_url($steam_user['profile_url']); ?>" target="_blank" rel="noopener noreferrer">
                            View Steam Profile →
                        </a>
                    </div>
                </div>

            <?php endif; ?>

        <?php else : ?>

            <a href="<?php echo esc_url($openid_url); ?>" class="scp-btn scp-btn-steam">
                <?php echo $is_logged_in ? 'Connect Steam Account' : 'Login with Steam'; ?>
            </a>

        <?php endif; ?>
    </div>
    <?php

    return ob_get_clean();
}
add_shortcode('steam_connect_button', 'scp_steam_connect_shortcode');


add_action('wp_head', function () {
    ?>
    <style>
        .scp-header-steam-login-btn {
            display: inline-flex!important;;
            align-items: center!important;
            gap: 8px;
        }

        .scp-header-steam-login-icon {
            width: 18px;
            height: 18px;
            object-fit: contain;
            flex: 0 0 18px;
        }
    </style>
    <?php
});



/**
 * Shortcode: [steam_login_button_simple]
 * Minimal Steam login/register button for custom headers.
 * Shows only for logged-out visitors.
 */
function scp_steam_login_button_simple_shortcode() {

    // شرط حذف شد

    $request_uri = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '/';

    $request_uri = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '/';
    $current_url = esc_url(home_url(add_query_arg([], $request_uri)));
    $openid_url = scp_get_steam_openid_url($current_url);

    // Upload your icon to: /wp-content/uploads/steam/steam-icon.png
    // Or override via filter: add_filter('scp_header_steam_icon_url', fn($url) => '...');
    $icon_url = get_stylesheet_directory_uri() . '/assets/img/steam.png';

    ob_start();
    ?>
    <a href="<?php echo esc_url($openid_url); ?>" class="scp-btn scp-btn-steam scp-header-steam-login-btn">
        <img src="<?php echo esc_url($icon_url); ?>" class="scp-header-steam-login-icon" alt="Steam" loading="lazy" decoding="async">
        <span>اتصال آکانت Steam</span>
    </a>
    <?php

    return ob_get_clean();
}
add_shortcode('steam_login_button_simple', 'scp_steam_login_button_simple_shortcode');


/**
 * OpenID callback handling with verification.
 * Verifies the OpenID response with Steam before trusting the steamid.
 * If Steam account is already linked to a user, logs that user in.
 * If not linked, creates a new user and logs them in.
 */
add_action('init', function () {
    $request_uri = isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '';

    $openid_mode = sanitize_text_field($_GET['openid_mode'] ?? '');

if (
    $openid_mode === 'id_res' &&

        strpos($request_uri, '/steam-auth-callback') !== false &&
        isset($_GET['openid_claimed_id'])
    ) {
        $verify_params = [];

        foreach ($_GET as $key => $value) {
            if (strpos($key, 'openid_') === 0) {
                $new_key = str_replace('openid_', 'openid.', $key);
                $verify_params[$new_key] = wp_unslash($value);
            }
        }

        if (
            empty($verify_params['openid.claimed_id']) ||
            !preg_match('#^https?://steamcommunity.com/openid/id/(\d+)$#', $verify_params['openid.claimed_id'], $matches)
        ) {
            wp_safe_redirect(home_url('/?steam_error=1'));
            exit;
        }

        $verify_params['openid.mode'] = 'check_authentication';

        $response = wp_remote_post(
            'https://steamcommunity.com/openid/login',
            [
                'body'    => $verify_params,
                'timeout' => 10,
            ]
        );

        if (is_wp_error($response)) {
            wp_safe_redirect(home_url('/?steam_error=1'));
            exit;
        }

        $body = wp_remote_retrieve_body($response);

        if (strpos($body, 'is_valid:true') === false) {
            wp_safe_redirect(home_url('/?steam_error=1'));
            exit;
        }

        $steam_id = sanitize_text_field($matches[1]);

if (!preg_match('/^\d{17}$/', $steam_id)) {
    wp_safe_redirect(home_url('/?steam_error=1'));
    exit;
}

        $current_user_id = get_current_user_id();

        // Check if this Steam account is already linked.
        $existing_user_id = scp_find_user_by_steam_id($steam_id);

        // Logged in user: connect/update their Steam account.
        if ($current_user_id) {
            // Prevent linking a Steam account that belongs to another user.
            if ($existing_user_id && (int) $existing_user_id !== (int) $current_user_id) {
                wp_safe_redirect(home_url('/?steam_already_registered=1'));
                exit;
            }

            delete_user_meta($current_user_id, 'steam_id');
            update_user_meta($current_user_id, 'steam_id', $steam_id);
            scp_sync_steam_profile_meta($current_user_id, $steam_id);

            $redirect_url = home_url('/?steam_connected=1');

            if (!empty($_GET['redirect'])) {
                $maybe = esc_url_raw(wp_unslash($_GET['redirect']));
                if (strpos($maybe, home_url()) === 0) {
                    $redirect_url = add_query_arg('steam_connected', '1', $maybe);
                }
            }

            wp_safe_redirect($redirect_url);
            exit;
        }

        // Logged out user + existing Steam link => login.
        if ($existing_user_id) {
            wp_set_current_user($existing_user_id);
            wp_set_auth_cookie($existing_user_id, true);

            $user = get_userdata($existing_user_id);
            if ($user) {
                do_action('wp_login', $user->user_login, $user);
            }

            scp_sync_steam_profile_meta($existing_user_id, $steam_id);

            $redirect_url = home_url('/?steam_login_success=1');

            if (!empty($_GET['redirect'])) {
                $maybe = esc_url_raw(wp_unslash($_GET['redirect']));
                if (strpos($maybe, home_url()) === 0) {
                    $redirect_url = add_query_arg('steam_login_success', '1', $maybe);
                }
            }

            wp_safe_redirect($redirect_url);
            exit;
        }

        // Logged out user + Steam not linked yet => register then login.
        $user_id = scp_create_user_from_steam($steam_id);

        if (!$user_id) {
            wp_safe_redirect(home_url('/?steam_error=1'));
            exit;
        }

        wp_set_current_user($user_id);
        wp_set_auth_cookie($user_id, true);

        $user = get_userdata($user_id);
        if ($user) {
            do_action('wp_login', $user->user_login, $user);
        }

        $redirect_url = home_url('/?steam_register_success=1');

        if (!empty($_GET['redirect'])) {
            $maybe = esc_url_raw(wp_unslash($_GET['redirect']));
            if (strpos($maybe, home_url()) === 0) {
                $redirect_url = add_query_arg('steam_register_success', '1', $maybe);
            }
        }

        wp_safe_redirect($redirect_url);
        exit;

    }
});

/**
 * Disconnect handler
 */
add_action('admin_post_scp_disconnect_steam', 'scp_handle_disconnect');
add_action('admin_post_nopriv_scp_disconnect_steam', 'scp_handle_disconnect');

function scp_handle_disconnect() {
    if (!is_user_logged_in() || !check_admin_referer('scp_disconnect_action', 'scp_disconnect_nonce')) {
        wp_safe_redirect(home_url('/?steam_error=1'));
        exit;
    }

    $user_id = get_current_user_id();

    // Keep cached Steam profile meta after disconnect.
    // This mirrors the requested behavior so avatar/name remain reusable.
    delete_user_meta($user_id, 'steam_id');

    wp_safe_redirect(home_url('/?steam_disconnected=1'));
    exit;
}
